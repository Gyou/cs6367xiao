package main;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

import java.io.*;

public class Agent_Main {
    /**
     * Author Xiao Li
     */
    public static void premain(String agentArgs, Instrumentation inst){
        //System.out.println("premain方法");
        //System.out.println(agentArgs);
        inst.addTransformer(new ClassFileTransformer() {
            @Override
            public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                FileWriter fw;
                try
                {
                    File file = new File("stmt-cov.txt");
                    if (file.exists())
                        file.delete();
                    else
                        file.createNewFile();
                    //fw = new FileWriter("stmt-cov.txt",true);
                    if (!className.substring(0, 4).equals("java") && !className.substring(0, 3).equals("sun") && !className.substring(0, 10).equals("org/apache") &&!className.substring(0, 3).equals("jdk")&&!className.substring(0, 3).equals("com")) {
                        System.out.print("[TEST]\t" + className + ":");
                        fw = new FileWriter(file,true);

                        fw.write("[TEST]\t" + className + ": ");
                        fw.flush();
                        fw.close();
                        ClassReader reader = new ClassReader(classfileBuffer);
                        ClassWriter writer = new ClassWriter(reader, 0);
                        ClassPrinter visitor = new ClassPrinter(writer);
                        reader.accept(visitor, 0);
                        System.out.println("traverse finished");

                    }

                }
                catch (Exception ex)
                {
                    ex.printStackTrace();

                }

                return new byte[0];
            }

        });
    }

}