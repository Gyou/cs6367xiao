import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

class MethodTransformVisitor extends MethodVisitor implements Opcodes {

    String mName; int line;

    static FileWriter fw;
    public MethodTransformVisitor(final MethodVisitor mv, String name) { super(ASM5, mv); this.mName=name; }

    // method coverage collection
    @Override
    public void visitCode(){

        mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
        mv.visitLdcInsn(mName+" executed");
        System.out.println("Method name "+mName);
        try
        {
            fw = new FileWriter("stmt-cov.txt",true);
            fw.write("Method name: "+mName + "\n");
            fw.flush();
            fw.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();

        }
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
        super.visitCode();

    }


    @Override public void visitLineNumber(int line, Label start) {
        this.line=line;
        mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
        mv.visitLdcInsn("line "+line+" executed");
        System.out.println(mName+" : "+line);
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
        super.visitLineNumber(line, start);
        try
        {
            fw = new FileWriter("stmt-cov.txt",true);
            fw.write(mName+" : "+line +"\n");

            fw.flush();
            fw.close();
            //System.out.println("writing successfully");
        }
        catch (Exception ex)
        {
            ex.printStackTrace();

        }
    }

    // collect line coverage for each label
    @Override public void visitLabel(Label label){
        mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
        mv.visitLdcInsn("line "+line+" executed");
        System.out.println(mName+" : "+line);
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
        super.visitLabel(label);
        try
        {
            //File file = new File("stmt-cov.txt");
            fw = new FileWriter("stmt-cov.txt",true);
            fw.write(mName+" : "+line+"\n");
            fw.flush();
            fw.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();

        }
    }



}
