package phase2;

import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.RunListener;

public class MyTraceListener extends RunListener {

    private OrgTrace org;

    @Override
    public void testRunStarted(Description description) throws Exception {
        super.testRunStarted(description);
        org = OrgTrace.getInstance();
    }

    @Override
    public void testRunFinished(Result result) throws Exception {
        super.testRunFinished(result);
        org.complete();
    }

    @Override
    public void testStarted(Description description) throws Exception {
        super.testStarted(description);
        String trace = "[TEST] " + description.getClassName() + ":" + description.getMethodName();
        org.addCase(trace);
    }
}

